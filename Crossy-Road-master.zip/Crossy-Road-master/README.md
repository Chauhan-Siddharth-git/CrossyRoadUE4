Crossy Road 
=========================
Description
-------------------
This is the popular mobile game Crossy Road recreated using Unreal Engine. Not all of the original mechanics of the game are there such as eagles but the core gameplay mechanics are implemented.

How to run project
--------------------  
Download "CrossyRoadEXE.zip" file then extract it and run "CrossyRoad.exe" (somewhat decent computer needed to run optimally)

Controls
--------------------
WASD - up, down, left, right movement of Chicken

Pictures  
--------
<a href="https://ibb.co/0BWZ9pf"><img src="https://i.ibb.co/RhMP6GC/image.png" alt="image" border="0" /></a>

<a href="https://ibb.co/hsTB6ZF"><img src="https://i.ibb.co/8MQrCdg/Crossy-Road.png" alt="Crossy-Road" border="0" /></a>
